﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace AvivationDemoDataLayer
{
    
    public class FlightMakeInfo : IValidatableObject


    {
        [Key]
        public long lSyskey { get; set; }
        [Required]
        [StringLength(128,ErrorMessage ="Cannot exceed 128 characters")]
        
        public String Make { get; set; }
        [Required]
        [StringLength(128, ErrorMessage = "Cannot exceed 128 characters")]
        public String Model { get; set; }
        [Required]
        [StringLength(8, ErrorMessage = "Cannot exceed 8 characters")]
        [RegularExpression(@"^(([A-za-z]{1,2}[-]{1}[A-za-z]{1,5}))$", ErrorMessage = " Invalid Registration")]
        public string Registration { get; set; }
        [Required]
        [StringLength(255, ErrorMessage = "Cannot exceed 255 characters")]
        public string Location { get; set; }
        [Required]
        [DataType(dataType:System.ComponentModel.DataAnnotations.DataType.DateTime)]
        public DateTime dtDate { get; set; }        
        public string Photopath { get; set; }
        public string NewPhotopath { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            List<ValidationResult> Result = new List<ValidationResult>();
            if (dtDate > DateTime.Now)
            {
                Result.Add(new ValidationResult("date and time must not be greater than current time", new[] { "dtDate" }));
            }
            return Result;

        }
    }

    public class clsReturn
    {
        public int iRc { get; set; }
        public string sResult { get; set; }
    }
}
