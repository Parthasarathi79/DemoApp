﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AvivationDemoDataLayer;

namespace AviationDemoApi.Controllers
{
    public class AvivationController : ApiController
    {
        [Route("api/Avivation/GetMakeInfo")]
        [HttpGet]
        public List<FlightMakeInfo> GetMakeInfo(string Type, string Value)
        {
            List<FlightMakeInfo> MakeDet = new List<FlightMakeInfo>();
            if (Type == null)
            {
                using (var DBLayer = new DemoEntities())
                {
                    MakeDet = DBLayer.MakeInfoes.Select(FOut => new FlightMakeInfo()
                    {
                        lSyskey = FOut.lSysKey,
                        Make = FOut.Make,
                        Model = FOut.Model,
                        Registration = FOut.Registration,
                        Location = FOut.Location,
                        dtDate = FOut.dtDate

                    }).ToList();
                }
            }
            else if (Type != null && Value != null)
            {
                if (Type == "Model" && Value != null)
                {
                    using (var DBLayer = new DemoEntities())
                    {
                        MakeDet = DBLayer.MakeInfoes.Where(I => I.Model == Value).Select(FOut => new FlightMakeInfo()
                        {
                            lSyskey = FOut.lSysKey,
                            Make = FOut.Make,
                            Model = FOut.Model,
                            Registration = FOut.Registration,
                            Location = FOut.Location,
                            dtDate = FOut.dtDate

                        }).ToList();
                    }
                }

                else if (Type == "Make" && Value != null)
                {
                    using (var DBLayer = new DemoEntities())
                    {
                        MakeDet = DBLayer.MakeInfoes.Where(I => I.Make == Value).Select(FOut => new FlightMakeInfo()
                        {
                            lSyskey = FOut.lSysKey,
                            Make = FOut.Make,
                            Model = FOut.Model,
                            Registration = FOut.Registration,
                            Location = FOut.Location,
                            dtDate = FOut.dtDate

                        }).ToList();
                    }
                }

                else if (Type == "Registrataion" && Value != null)
                {
                    using (var DBLayer = new DemoEntities())
                    {
                        MakeDet = DBLayer.MakeInfoes.Where(I => I.Registration == Value).Select(FOut => new FlightMakeInfo()
                        {
                            lSyskey = FOut.lSysKey,
                            Make = FOut.Make,
                            Model = FOut.Model,
                            Registration = FOut.Registration,
                            Location = FOut.Location,
                            dtDate = FOut.dtDate

                        }).ToList();
                    }
                }
            }
            return MakeDet;
        }


        [Route("api/Avivation/GetFlightInfo")]
        [HttpGet]
        public List<FlightMakeInfo> GetFlightInfo(int Id)
        {
            List<FlightMakeInfo> MakeDet = new List<FlightMakeInfo>();
            using (var DBLayer = new DemoEntities())
            {
                MakeDet = DBLayer.MakeInfoes.Where(I => I.lSysKey == Id).Select(FOut => new FlightMakeInfo()
                {
                    lSyskey = FOut.lSysKey,
                    Make = FOut.Make,
                    Model = FOut.Model,
                    Registration = FOut.Registration,
                    Location = FOut.Location,
                    dtDate = FOut.dtDate,
                    Photopath = FOut.FlightPhoto

                }).ToList();
            }
            return MakeDet;
        }

        [Route("api/Avivation/UpdateFlightInfo")]
        [HttpPost]
        public clsReturn UpdateFlightInfo(FlightMakeInfo FInfo)
        {
            clsReturn ReturnInfo = new clsReturn();
            ReturnInfo.iRc = 0;
            ReturnInfo.sResult = String.Empty;
            try
            {
                var DBLayer = new DemoEntities();

                var MakeDet = DBLayer.MakeInfoes.Where(i => i.lSysKey == FInfo.lSyskey).Single();



                if (MakeDet != null)
                {
                    if (MakeDet.lSysKey > 0)
                    {

                        MakeDet.Make = FInfo.Make;
                        MakeDet.Model = FInfo.Model;
                        MakeDet.Registration = FInfo.Registration;
                        MakeDet.Location = FInfo.Location;
                        MakeDet.dtDate = FInfo.dtDate;
                        MakeDet.FlightPhoto = FInfo.Photopath;

                        DBLayer.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {

                ReturnInfo.iRc = 1;
                ReturnInfo.sResult = ex.Message.ToString();
            }

            return ReturnInfo;
        }


        [Route("api/Avivation/InsertFlightInfo")]
        [HttpPost]
        public clsReturn InsertFlightInfo(FlightMakeInfo FInfo)
        {
            clsReturn returnInfo = new clsReturn();
            returnInfo.iRc = 0;
            returnInfo.sResult = "";
            try
            {
                var DBLayer = new DemoEntities();

                MakeInfo MakeDet = new MakeInfo();

                MakeDet.Make = FInfo.Make;
                MakeDet.Model = FInfo.Model;
                MakeDet.Registration = FInfo.Registration;
                MakeDet.Location = FInfo.Location;
                MakeDet.dtDate = FInfo.dtDate;
                MakeDet.FlightPhoto = FInfo.Photopath;
                DBLayer.MakeInfoes.Add(MakeDet);
                DBLayer.SaveChanges();
            }
            catch (Exception ex)
            {

                returnInfo.iRc = 1;
                returnInfo.sResult = ex.Message;
            }
            return returnInfo;
        }
    }
}
