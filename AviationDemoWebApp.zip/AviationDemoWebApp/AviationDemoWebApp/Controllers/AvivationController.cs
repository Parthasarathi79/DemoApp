﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AvivationDemoDataLayer;
using System.Configuration;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;
using System.IO;
namespace AviationDemoWebApp.Controllers
{
    public class AvivationController : Controller
    {
        // GET: Avivation
        public async System.Threading.Tasks.Task<ActionResult> Index(string Type, string Value)
        {
            List<FlightMakeInfo> Model = new List<FlightMakeInfo>();
            string Baseurl = ConfigurationManager.AppSettings["RESTAPI"];
            using (var HPClient = new HttpClient())
            {
                HPClient.BaseAddress = new Uri(Baseurl);
                HPClient.DefaultRequestHeaders.Clear();
                                
                HttpResponseMessage Res = await HPClient.GetAsync(string.Format("api/Avivation/GetMakeInfo?Type={0}&Value={1}", Type,Value));
                if (Res.IsSuccessStatusCode)
                {
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    Model = JsonConvert.DeserializeObject<List<FlightMakeInfo>>(Response);
                }
            }
            return View(Model.ToList());
        }



        public async System.Threading.Tasks.Task<ActionResult> Edit(int Id)
        {

            List<FlightMakeInfo> FModel = new List<FlightMakeInfo>();
            FlightMakeInfo ReturnInfo = new FlightMakeInfo();
            string Baseurl = ConfigurationManager.AppSettings["RESTAPI"];
            using (var HPClient = new HttpClient())
            {
                HPClient.BaseAddress = new Uri(Baseurl);
                HPClient.DefaultRequestHeaders.Clear();

                HttpResponseMessage Res = await HPClient.GetAsync(string.Format("api/Avivation/GetFlightInfo?Id={0}", Id));
                if (Res.IsSuccessStatusCode)
                {
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    FModel = JsonConvert.DeserializeObject<List<FlightMakeInfo>>(Response);
                    if (FModel.Count > 0)
                    {
                        ReturnInfo = FModel[0];
                    }

                }
            }
            return View(ReturnInfo);
        }

        public async System.Threading.Tasks.Task<ActionResult> Details(int Id)
        {

            List<FlightMakeInfo> FModel = new List<FlightMakeInfo>();
            FlightMakeInfo ReturnInfo = new FlightMakeInfo();
            string Baseurl = ConfigurationManager.AppSettings["RESTAPI"];
            using (var HPClient = new HttpClient())
            {
                HPClient.BaseAddress = new Uri(Baseurl);
                HPClient.DefaultRequestHeaders.Clear();

                HttpResponseMessage Res = await HPClient.GetAsync(string.Format("api/Avivation/GetFlightInfo?Id={0}", Id));
                if (Res.IsSuccessStatusCode)
                {
                    var Response = Res.Content.ReadAsStringAsync().Result;
                    FModel = JsonConvert.DeserializeObject<List<FlightMakeInfo>>(Response);
                    if (FModel.Count > 0)
                    {
                        ReturnInfo = FModel[0];
                    }

                }
            }
            return View(ReturnInfo);
        }

        [HttpPost]
        public async System.Threading.Tasks.Task<ActionResult> Edit(FlightMakeInfo FInfo)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    HttpFileCollectionBase files = Request.Files;
                    string path = Server.MapPath("~/Images/");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    if (files.Count > 0)
                    {
                        string filename = Path.GetFileName(Request.Files[0].FileName);
                        HttpPostedFileBase UFile = files[0];

                        if (UFile.FileName != null)
                        {
                            string fileName = Path.GetFileName(UFile.FileName);
                            string Upload = path + fileName;
                            UFile.SaveAs(Upload);
                            FInfo.Photopath = "~/Images/" + fileName;
                        }
                    }

                    clsReturn Result = new clsReturn();
                    string Baseurl = ConfigurationManager.AppSettings["RESTAPI"];
                    using (var HPClient = new HttpClient())
                    {
                        HPClient.BaseAddress = new Uri(Baseurl);
                        HPClient.DefaultRequestHeaders.Clear();

                        // var Res = await HPClient.PostAsJsonAsync<FlightMakeInfo>("FInfo", FInfo);
                        var Res = await HPClient.PostAsync("api/Avivation/UpdateFlightInfo", new StringContent(JsonConvert.SerializeObject(FInfo), Encoding.UTF8, "application/json"));
                        if (Res.IsSuccessStatusCode)
                        {
                            var Response = Res.Content.ReadAsStringAsync().Result;
                            Result = JsonConvert.DeserializeObject<clsReturn>(Response);
                            if (Result.iRc == 1)
                            {
                                ModelState.AddModelError(string.Empty, Result.sResult);
                            }
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Response got Error");
                        }

                    }
                    return RedirectToAction("Index");
                }
                else
                {
                    return View(FInfo);
                }

            }
            catch (Exception ex)
            {

                ModelState.AddModelError(string.Empty, ex.Message);
                return View(FInfo);
            }           

        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async System.Threading.Tasks.Task<ActionResult> Create(FlightMakeInfo FInfo)
        {
            if (ModelState.IsValid)
            {
                HttpFileCollectionBase files = Request.Files;
                string path = Server.MapPath("~/Images/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                if (files.Count > 0)
                {
                    string filename = Path.GetFileName(Request.Files[0].FileName);
                    HttpPostedFileBase UFile = files[0];

                    if (UFile.FileName != null)
                    {
                        string fileName = Path.GetFileName(UFile.FileName);
                        string Upload = path + fileName;
                        UFile.SaveAs(Upload);
                        FInfo.Photopath = "~/Images/" + fileName;
                    }
                }

                clsReturn Result = new clsReturn();
                string Baseurl = ConfigurationManager.AppSettings["RESTAPI"];
                using (var HPClient = new HttpClient())
                {
                    HPClient.BaseAddress = new Uri(Baseurl);
                    HPClient.DefaultRequestHeaders.Clear();

                    // var Res = await HPClient.PostAsJsonAsync<FlightMakeInfo>("FInfo", FInfo);
                    var Res = await HPClient.PostAsync("api/Avivation/InsertFlightInfo", new StringContent(JsonConvert.SerializeObject(FInfo), Encoding.UTF8, "application/json"));
                    if (Res.IsSuccessStatusCode)
                    {
                        var Response = Res.Content.ReadAsStringAsync().Result;
                        Result = JsonConvert.DeserializeObject<clsReturn>(Response);
                        if (Result.iRc == 1)
                        {
                            ModelState.AddModelError(string.Empty, Result.sResult);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Response got Error");
                    }

                }
                return RedirectToAction("Index");
            }
            else
            {
                return View(FInfo);
            }
        }
    }
}