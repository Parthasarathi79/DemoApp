﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AviationDemoWebApp.Startup))]
namespace AviationDemoWebApp
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
           // ConfigureAuth(app);
        }
    }
}
